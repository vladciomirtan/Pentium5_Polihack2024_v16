// Latitude and longitude data for Cluj-Napoca:
const float latitude = 46.7667;
const float longitude = 23.6;

// Network information:
const char* ssid = "cloudflight-guest";
const char* pass = "digitalfuture";

// OpenMeteo API:
// Returns current date and time, as well as UV max index and clear sky index:
// const arduino::String api_url = "https://api.open-meteo.com/v1/forecast?latitude=" + latitude + " &longitude=" + longitude + "&current=temperature_2m,relative_humidity_2m&daily=uv_index_max,uv_index_clear_sky_max&timezone=auto&forecast_days=1";
const char* endpoint = "/v1/forecast?latitude=46.7667&longitude=23.6&current=temperature_2m,relative_humidity_2m&daily=uv_index_max,uv_index_clear_sky_max&timezone=auto&forecast_days=1";
const char* host = "api.open-meteo.com";

//const String httpresponse = "HTTP/1.1 200 OK\nDate: Sat, 07 Dec 2024 15:35:10 GMT\nContent-Type: application/json; charset=utf-8\nTransfer-Encoding: chunked\nConnection: close\n";